# block_access
This is a plugin to secure your Joomla website. With this plugin you can block access to the frontend, the backend or both.

### setup
- After installation, just go to yoursite.com/?option=com_plugins and search for "zugangskontrolle"
- Open the plugins configuration and set up all options you want
- Enable it --> that's it.
